# SwachhData

## Authors-
* Kritik Seth
